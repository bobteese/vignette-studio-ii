<?php 


$_SESSION['IVETTitle']    = "Torque and Rotation Problem 1";
$_SESSION['IVETProject']  = "Interactive Video-Enhanced Tutorials";
$_SESSION['ivet']         = "TRp";


?>