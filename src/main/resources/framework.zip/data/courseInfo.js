        var cid = "5000"; // cid is the Course ID number
        var IVETTitle = "Introduction to IVET"; // Full title of the tutorial
        var IVETProject = "Interactive Video-Enhanced Tutorials";
        var ivet = "II"; // This is a short symbolic title for the tutorial
        var school = "RIT";
        var schoolFull = "Rochester Institute of Technology";
        var instructor = "Dr. Teese";
        var courseName = "University Physics";
        var courseNumber = "PHYS 211";
        var courseTerm = "Fall 2021";
        var playerChoice; // 1 = Youtube & 0 = Vimeo
        var firstPageFilename = "pages/login.html"; // Page to load as first page
