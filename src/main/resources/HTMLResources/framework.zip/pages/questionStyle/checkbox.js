// Style and class in this file goes into the <input> inside if(q.questionType == "checkbox") 

var style = {
    "font-weight": "bold"
};

var classes = ["custom_question_answer"];