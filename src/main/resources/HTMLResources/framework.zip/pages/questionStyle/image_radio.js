// Style and class in this file goes into the <img> inside if(q.questionType == "radio") and if(Pattern.matches) 

var style = {
    "width": "150px",
    "height": "150px",
};

var classes = ["custom_question_answer"];