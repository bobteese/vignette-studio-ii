// Style and class in this file goes into the <input> inside if(q.questionType == "text") 

var style = {
    "font-size": "medium",
    "font-weight": "normal",
    "height": "60px"
};

var classes = ["custom_question_answer"];