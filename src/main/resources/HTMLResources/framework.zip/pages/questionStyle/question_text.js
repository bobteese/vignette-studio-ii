// Style and class in this file goes into the <p> tag containing question text ie Q1. Enter your question here

var style = {
    'padding': "0px 15px 0px",
    'text-align':"right",
    'width': "95%",
};

var classes = ["normalTxt"];