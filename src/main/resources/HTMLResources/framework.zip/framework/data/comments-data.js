var commentsArray = [
{
   "id": 20517,
   "created": "2015-01-01",
   "content": "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed posuere interdum sem. Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu.",
   "fullname": "rit-37",
   "upvote_count": 3,
   "user_has_upvoted": false
},

{
   "id": 10321,
	"created": "2020-06-06T22:16:26.308Z",
   "content": "Sed posuere interdum sem. Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu.",
   "fullname": "uc-96",
   "upvote_count": 2,
   "user_has_upvoted": false
},

{
   "id": 7892,
   "created": "2020-06-06T21:16:26.308Z",
   "content": "@Hank Smith sed posuere interdum sem.\nQuisque ligula eros ullamcorper  quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu. Sed arcu lectus auctor vitae, consectetuer et venenatis eget #velit.",
   "fullname": "uc-63",
   "upvote_count": 2,
   "user_has_upvoted": true
},

{
   "id": 4765,
   "created": "2020-06-06T20:10:20.308Z",
   "content": "",
   "fullname": "rit-103",
   "upvote_count": 0,
   "user_has_upvoted": false
},

{
   "id": 5326,
   "created": "2015-01-05",
   "content": "Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu. Sed arcu lectus auctor vitae, consectetuer et venenatis eget velit.",
   "fullname": "uc-232",
   "upvote_count": 0,
   "user_has_upvoted": false
},

{
   "id": 6,
   "created": "2015-01-06",
   "content": "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed posuere interdum sem. Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu.",
   "fullname": "uc-74",
   "upvote_count": 1,
   "user_has_upvoted": false
},

{
   "id": 10,
   "created": "2015-01-07",
   "content": "Sed posuere interdum sem. Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu. Sed arcu lectus auctor vitae, consectetuer et venenatis eget velit.",
   "fullname": "uc-19",
   "upvote_count": 0,
   "user_has_upvoted": false
},

{
   "id": 11,
   "created": "2015-01-08",
   "content": "Sed posuere interdum sem. Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu.",
   "fullname": "rit-523",
   "upvote_count": 0,
   "user_has_upvoted": false
},

{
   "id": 12,
   "created": "2015-01-09",
   "content": "Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu. Sed arcu lectus auctor vitae, consectetuer et venenatis eget velit.",
   "fullname": "uc-83",
   "upvote_count": 0,
   "user_has_upvoted": false
},

{
   "id": 104,
   "created": "2015-01-10",
   "content": "Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu. Sed arcu lectus auctor vitae, consectetuer et venenatis eget velit.",
   "fullname": "rit-46",
   "upvote_count": 0,
   "user_has_upvoted": false
}
]
