<?php
$commentsArray = '[
{
   "id": 20517,
   "created": "2015-01-01",
   "content": "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed posuere interdum sem. Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu.",
   "fullname": "phpRIT-37",
   "upvote_count": 3,
   "user_has_upvoted": false
},

{
   "id": 10321,
	"created": "2020-06-06T22:16:26.308Z",
   "content": "Sed posuere interdum sem. Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu.",
   "fullname": "PHPuc-96",
   "upvote_count": 2,
   "user_has_upvoted": false
},

{
   "id": 7892,
   "created": "2020-06-06T21:16:26.308Z",
   "content": "@Hank Smith sed posuere interdum sem.\nQuisque ligula eros ullamcorper  quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu. Sed arcu lectus aPHPuctor vitae, consectetuer et venenatis eget #velit.",
   "fullname": "PHPuc-63",
   "upvote_count": 2,
   "user_has_upvoted": true
},

{
   "id": 4765,
   "created": "2020-06-06T20:10:20.308Z",
   "content": "",
   "fullname": "phpRIT-103",
   "upvote_count": 0,
   "user_has_upvoted": false
},

{
   "id": 5326,
   "created": "2015-01-05",
   "content": "Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu. Sed arcu lectus aPHPuctor vitae, consectetuer et venenatis eget velit.",
   "fullname": "PHPuc-232",
   "upvote_count": 0,
   "user_has_upvoted": false
},

{
   "id": 6,
   "created": "2015-01-06",
   "content": "Lorem ipsum dolor sit amet, consectetuer adipiscing elit. Sed posuere interdum sem. Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu.",
   "fullname": "PHPuc-74",
   "upvote_count": 1,
   "user_has_upvoted": false
},

{
   "id": 10,
   "created": "2015-01-07",
   "content": "Sed posuere interdum sem. Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu. Sed arcu lectus aPHPuctor vitae, consectetuer et venenatis eget velit.",
   "fullname": "PHPuc-19",
   "upvote_count": 0,
   "user_has_upvoted": false
},

{
   "id": 11,
   "created": "2015-01-08",
   "content": "Sed posuere interdum sem. Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu.",
   "fullname": "phpRIT-523",
   "upvote_count": 0,
   "user_has_upvoted": false
},

{
   "id": 12,
   "created": "2015-01-09",
   "content": "Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu. Sed arcu lectus aPHPuctor vitae, consectetuer et venenatis eget velit.",
   "fullname": "PHPuc-83",
   "upvote_count": 0,
   "user_has_upvoted": false
},

{
   "id": 104,
   "created": "2015-01-10",
   "content": "Quisque ligula eros ullamcorper quis, lacinia quis facilisis sed sapien. Mauris varius diam vitae arcu. Sed arcu lectus aPHPuctor vitae, consectetuer et venenatis eget velit.",
   "fullname": "phpRIT-46",
   "upvote_count": 0,
   "user_has_upvoted": false
}
]';

?>